# Java Lab Record - P Revanth Sai
Single-file static website. Deploy on Vercel with Framework Preset "Other", no build command.
